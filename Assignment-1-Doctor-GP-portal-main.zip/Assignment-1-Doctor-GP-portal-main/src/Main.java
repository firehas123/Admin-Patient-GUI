//Authors: Rielle
public class Main {
    public static void main(String[] args) {
        loginPanel baseLoginPanel = new loginPanel();
        GUI panel1 = new GUI("Login", baseLoginPanel);
    }
}