import java.awt.*;
import java.awt.event.*;
import java.sql.SQLException;
import javax.swing.*;

//Version 0.1
//Authors: Rielle

//This is a specialised Jpanel object intended to create a basic login system
//ActionListener here is how we parse actions the user takes in the right context
public class loginPanel extends JPanel implements ActionListener{

    //These protected variables are initialising the different objects that will populate the GUI
    protected JTextField idField;
    protected JPasswordField passwordField;
    protected JRadioButton passwordHider;

    protected JButton loginButton;

    protected JLabel invalidLogin;

    public String docID;

    //Password hidden is a simple bool check variable used by the passwordHider radio button
    //This allows it to check when the button is clicked whether the password is hidden or not, giving the button its functionality
    private boolean passwordHidden;

    //The login panel constructor that forms and shows the login panels GUI
    public loginPanel() {
        super(new GridBagLayout());

        //These simply create the widgets for the GUI
        idField = new JTextField("Enter your doctor ID",20);
        idField.addActionListener(getInput);

        passwordField = new JPasswordField("Enter your pasword",20);
        passwordField.addActionListener(getInput);

        //passwordField.setEchoChar('0');
        //passwordField.setEchoChar('*');

        passwordHider = new JRadioButton("Hide Password");
        passwordHider.addActionListener(passwordState);

        //Echo character is the means with which a specific J password field can have the text hidden
        //In this case the char(0) causes the field to be unhidden, the defualt state in order to show the intial text
        passwordField.setEchoChar((char)0);
        passwordHidden = false;

        loginButton = new JButton("Login");
        loginButton.addActionListener(getInput);

        invalidLogin = new JLabel();

        //This creates a grid and organises the widgets as added to it in that grid
        GridBagConstraints c = new GridBagConstraints();
        c.gridwidth = GridBagConstraints.REMAINDER;

        c.fill = GridBagConstraints.HORIZONTAL;
        add(idField, c);
        add(passwordField, c);
        add(passwordHider, c);
        add(loginButton, c);
        add(invalidLogin, c);

    }

    //The standard action listener referenced by this
    //Takes the inputs from the login fields and checks it against the database
    ActionListener getInput = new ActionListener() {
        public void actionPerformed(ActionEvent evt) {
            //id gets the id inputted from the first field
            String id = idField.getText();
            docID = id;
            //System.out.println(id);

            //password gets the password as inputted from the second field
            String password = passwordField.getText();
            //System.out.println(password);

            MySQl table = new MySQl();
            boolean check = table.checkLogin(id, password);

            if(check){
                //This is where I will move onto then next frame
                System.out.println("Valid Username and Password");
                //In future, this will close the login panel and go to a main menu
                //For sprint 1 and testing purposes, this goes straight to the patient info step
                Window window = SwingUtilities.getWindowAncestor(idField);
                window.dispose();
                try {
                    GUI panel2 = new GUI("Login", new patientInfoPanel(docID));
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }
            else{
                System.out.println("no");
                invalidLogin.setText("Your login details are not correct, check them and try again");
            }
        }
    };

    //An action listener for the hide password radio button
    //Hides or shows password depending on the state of the button
    ActionListener passwordState = new ActionListener() {
        public void actionPerformed(ActionEvent evt) {
            if (passwordHidden) {
                passwordField.setEchoChar((char)0);
                passwordHidden = false;
            }
            else {
                passwordField.setEchoChar('*');
                passwordHidden = true;
            }
        }
    };

    public void actionPerformed(ActionEvent e) {
    }

    
}

