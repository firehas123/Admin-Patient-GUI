import java.sql.*;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.Assert;
import org.junit.Test;

//This file requires an external library to be loaded
//Specifically the jdbc for MySQL


//This class creates a connection to the MySQL database
//Each function is set up to perform a different query and return the results as necessary
public class MySQl {

    //The url, username and password for the database, change as needed to test the program
    private String DbUrl = "jdbc:mysql://localhost:3306/gp";
    private String Dbusername = "root";
    private String Dbpassword = "1482TamsynMuir";

    //This function checks the login details against the database, providing authentication
    //Returns a true bool value if the password matches the given id, and false if not, to be handled by the loginPanel class
    public boolean checkLogin(String id, String password){
        try {
            //This section initialises the connection with the database using the given data as set above
            Connection connection = DriverManager.getConnection(DbUrl, Dbusername, Dbpassword);
            Statement statement = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            //This statement executes a query, the results of which are taken into the resultSet variable
            //This specific query gets the password in that database that matches with the given id
            ResultSet resultSet = statement.executeQuery("SELECT password FROM doctors WHERE Doctorid = " + id + ";");
            //System.out.println("checked!");
            resultSet.next();
            //System.out.println(resultSet.getString(1));
            //System.out.println(resultSet.getString(2));

            //These selection statements check whether the given password matches the one in the database
            //If it does, true is returned, otherwise it returns false to be handled in the loginPanel
            if (password.equals(resultSet.getString(1))){
                connection.close();
                System.out.println("true");
                return true;
            }
            else{
                connection.close();
                System.out.println("false");
                return false;
            }
        }
        catch(Exception e){
            System.out.println(e);
            return false;
        }
    }

    /**
     * Login Credential Checker Tests
     * Author: Kiera/Melanie
     */
     @Test
     public void correctCredentials () {
         boolean testCase = checkLogin("Dr.Norman", "test");
         Assert.assertTrue(testCase);
        }
     @Test
     public void invalidCredentials () {
         boolean testCase = checkLogin("Dr.Norman", "password");
         Assert.assertFalse(testCase);
     }
     @Test
     public void noUserName () {
         boolean testCase = checkLogin("", "password");
         Assert.assertFalse(testCase);
     }
     @Test
     public void noCredentials () {
         boolean testCase = checkLogin("", "");
         Assert.assertFalse(testCase);
     }
     @Test
     public void IDInsteadOfUsr () {
         boolean testCase = checkLogin("132762", "password");
         Assert.assertFalse(testCase);
     }
     @Test
     public void emailInsteadOfUsr () {
         boolean testCase = checkLogin("FallonMed@gmail.com", "");
         Assert.assertFalse(testCase);
     }

    public Container getPatientDetails(String id){
        try {
            //Again creating a connection to the database
            Connection connection = DriverManager.getConnection(DbUrl, Dbusername, Dbpassword);
            Statement statement = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);

            //A query that gathers all the patient information for a specific doctor
            ResultSet resultSet = statement.executeQuery("SELECT * FROM patient WHERE Doctorid = " + id + ";");

            //This is where the container class is used to return the Connection and ResultSet
            return new Container(resultSet,connection);
        }
        catch(Exception e){
            System.out.println(e);
            return null;
        }
    }
    /**
     * Booking Getter Tests
     * Author: Kiera/Melanie
     */
    @Test
    public void BookingGetterTest1 () {
        Container container = getBookings(3, 2024);
        boolean testCase = container.getResultSet() == null;
        Assert.assertFalse(testCase);
    }


    /**
     * get Bookings
     * @param Month
     * @param Year
     * @return bookings for the month and year entered
     * @author
     */
    public Container getBookings(int Month, int Year) {
        return null;
    }
}
