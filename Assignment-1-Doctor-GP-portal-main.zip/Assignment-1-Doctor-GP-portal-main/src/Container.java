import java.sql.Connection;
import java.sql.ResultSet;

//This is just a simple container class to allow me to return multiple variables at once from a method, in this case a ResultSet and a connection, specifically so i can return the connection so that it can be closed, as closing a connection to a database is important, but the connection must remain open in order to parse the data in a ResultSet.

public class Container {
    private ResultSet resultSet;

    private Connection connection;

    public Container(ResultSet rs, Connection con){
        resultSet = rs;
        connection = con;
    }

    public Connection getConnection() {
        return connection;
    }

    public ResultSet getResultSet() {
        return resultSet;
    }
}
