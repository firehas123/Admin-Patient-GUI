import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.*;




public class patientInfoPanel extends JPanel implements ActionListener{

    protected JLabel pIdLabel;
    protected JLabel pNameLabel;
    protected JLabel pDobLabel;
    protected JLabel pGenderLabel;
    protected JLabel pPnLabel;
    protected JLabel pEmailLabel;
    protected JLabel pAddressLabel;
    protected JButton nextButton;
    protected JButton prevButton;
    protected JLabel errorLabel;

    private ResultSet resultSet;

    private int rsPointer;
    private int rsSize;

    public patientInfoPanel(String docID) throws SQLException {
        super(new GridBagLayout());

        MySQl table = new MySQl();
        Container temp = table.getPatientDetails(docID);

        resultSet = temp.getResultSet();
        Connection connection = temp.getConnection();

        rsSize = 0;
        System.out.println(resultSet);
        if (resultSet.isBeforeFirst()) {
            resultSet.last();
            rsSize = resultSet.getRow();
            resultSet.first();
            rsPointer = 1;

            pIdLabel = new JLabel(resultSet.getString(1));
            pNameLabel = new JLabel(resultSet.getString(2) + " " + resultSet.getString(3));
            pDobLabel = new JLabel(resultSet.getString(4));
            pGenderLabel = new JLabel(resultSet.getString(5));
            pPnLabel = new JLabel(resultSet.getString(6));
            pEmailLabel = new JLabel(resultSet.getString(7));
            pAddressLabel = new JLabel(resultSet.getString(8));

            errorLabel = new JLabel();

            nextButton = new JButton("Next Patient");
            nextButton.addActionListener(next);

            prevButton = new JButton("Previous Patient");
            prevButton.addActionListener(previous);

            GridBagConstraints c = new GridBagConstraints();
            c.gridwidth = GridBagConstraints.REMAINDER;

            c.fill = GridBagConstraints.HORIZONTAL;
            add(pIdLabel, c);
            add(pNameLabel, c);
            add(pDobLabel, c);
            add(pGenderLabel, c);
            add(pPnLabel, c);
            add(pEmailLabel, c);
            add(pAddressLabel, c);
            add(nextButton, c);
            add(prevButton, c);
            add(errorLabel, c);
        }
        else {
            errorLabel = new JLabel("You have no active patients");
            GridBagConstraints c = new GridBagConstraints();
            c.gridwidth = GridBagConstraints.REMAINDER;

            c.fill = GridBagConstraints.HORIZONTAL;
            add(errorLabel, c);
        }
    }

    ActionListener next = new ActionListener() {
        public void actionPerformed(ActionEvent evt) {
            if (rsPointer < rsSize) {
                try {
                    resultSet.next();
                    rsPointer +=1;
                    pIdLabel.setText(resultSet.getString(1));
                    pNameLabel.setText(resultSet.getString(2) + " " + resultSet.getString(3));
                    pDobLabel.setText(resultSet.getString(4));
                    pGenderLabel.setText(resultSet.getString(5));
                    pPnLabel.setText(resultSet.getString(6));
                    pEmailLabel.setText(resultSet.getString(7));
                    pAddressLabel.setText(resultSet.getString(8));
                    errorLabel.setText("");
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }
            else {
                errorLabel.setText("There is not a next patient");
            }
        }
    };

    ActionListener previous = new ActionListener() {
        public void actionPerformed(ActionEvent evt) {
            if (rsPointer > 1) {
                try {
                    resultSet.previous();
                    rsPointer-=1;
                    pIdLabel.setText(resultSet.getString(1));
                    pNameLabel.setText(resultSet.getString(2) + " " + resultSet.getString(3));
                    pDobLabel.setText(resultSet.getString(4));
                    pGenderLabel.setText(resultSet.getString(5));
                    pPnLabel.setText(resultSet.getString(6));
                    pEmailLabel.setText(resultSet.getString(7));
                    pAddressLabel.setText(resultSet.getString(8));
                    errorLabel.setText("");
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }
            else {
                errorLabel.setText("There is no prior patient");
            }
        }
    };

    public void actionPerformed(ActionEvent e) {

    }
}
